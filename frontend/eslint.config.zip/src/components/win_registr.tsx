import { svg } from "d3";
import React from "react";

type NodeModalProps = {
  isOpen: boolean;
  nodeId: string | null;
  onClose: () => void;
  onAdd?: (nodeId: string) => void;
  onEdit?: (nodeId: string) => void;
};

const Win_Registr: React.FC<NodeModalProps> = ({ isOpen, nodeId, onClose, onAdd, onEdit }) => {
  if (!isOpen || !nodeId) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0,0,0,0.35)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 9999,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#fff",
          padding: 20,
          borderRadius: 8,
          minWidth: 320,
          boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
        }}
      >
        <h1 style={{display: "flex", justifyContent: "center", paddingBottom: "24px"}}>Регистрация</h1>
          <div style={{display: "flex", justifyContent: "center", gap: "5px", paddingBottom: "32px", flexDirection: "column"}}>
            <p>Ваше имя</p>
            <input type="text" />
            
            <p>Номер телефона</p>
            <input type="tel" />

            <p>Пароль</p>
            <input type="password" />

            <p>Повторите пароль</p>
            <input type="password" />
            
            <p><input type="checkbox" /> Запомнить меня</p>
        </div>
            
        {/* <h3 style={{ marginTop: 0 }}>Узел: {nodeId}</h3> */}
        <div style={{ display: "flex", justifyContent: "center", gap: "10px", marginTop: "10px" }}>
          {onAdd && (
            <button style={{border: "none", borderRadius: "4px", padding: "8px 11px", color: "#60646C"}} onClick={() => onAdd(nodeId)}>Зарегистрироваться</button>//Добавить
          )}
          {onEdit && (
            <button onClick={() => onEdit(nodeId)}>Создать аккаунт</button>//Редактировать
          )}
          <button style={{border: "none", borderRadius: "4px", color: "white", backgroundColor: "#30A46C", padding: "8px 80px"}} onClick={onClose}>Создать аккаунт</button>{/* Закрыть */}
        </div>
      </div>
    </div>
  );
};

export default Win_Registr;
