import React from "react";

type NodeModalProps = {
  isOpen: boolean;
  nodeId: string | null;
  onClose: () => void;
  onAdd?: (nodeId: string) => void;
  onEdit?: (nodeId: string) => void;
};

const NodeModal: React.FC<NodeModalProps> = ({ isOpen, nodeId, onClose, onAdd, onEdit }) => {
  if (!isOpen || !nodeId) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0,0,0,0.35)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 9999,
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#fff",
          padding: 20,
          borderRadius: 8,
          minWidth: 320,
          boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
        }}
      >
        <h3 style={{ marginTop: 0 }}>Узел: {nodeId}</h3>
        <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
          {onAdd && (
            <button onClick={() => onAdd(nodeId)}>Добавить</button>
          )}
          {onEdit && (
            <button onClick={() => onEdit(nodeId)}>Редактировать</button>
          )}
          <button onClick={onClose}>Закрыть</button>
        </div>
      </div>
    </div>
  );
};

export default NodeModal;
